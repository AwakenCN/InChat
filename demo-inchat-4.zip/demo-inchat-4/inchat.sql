/*
Navicat MySQL Data Transfer

Source Server         : centos7.6
Source Server Version : 50643
Source Host           : 192.168.192.133:3306
Source Database       : inchat

Target Server Type    : MYSQL
Target Server Version : 50643
File Encoding         : 65001

Date: 2019-08-23 16:24:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for message
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `one` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `online_group` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `online` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `groud_id` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `token` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `value` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `type` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES ('34', null, null, null, null, '1111', '', 'sendMe', '2019-08-22 14:35:07');
INSERT INTO `message` VALUES ('35', null, null, null, null, '2222', '', 'sendMe', '2019-08-22 14:35:09');
INSERT INTO `message` VALUES ('36', '1111', null, '1111', null, '2222', '', 'sendTo', '2019-08-22 14:35:12');
INSERT INTO `message` VALUES ('37', '2222', null, '2222', null, '1111', '', 'sendTo', '2019-08-22 14:35:15');
INSERT INTO `message` VALUES ('38', null, '3333、1111', null, '2', '2222', '', 'sendGroup', '2019-08-22 14:35:17');
INSERT INTO `message` VALUES ('39', null, '3333、2222', null, '2', '1111', '', 'sendGroup', '2019-08-22 14:35:19');
INSERT INTO `message` VALUES ('40', null, '3333、1111', null, '2', '2222', '', 'sendGroup', '2019-08-22 14:35:24');
INSERT INTO `message` VALUES ('41', null, '3333、2222', null, '2', '1111', '', 'sendGroup', '2019-08-22 14:35:37');
INSERT INTO `message` VALUES ('42', null, null, null, null, '2222', '', 'sendMe', '2019-08-22 04:32:25');
INSERT INTO `message` VALUES ('43', null, null, null, null, '2222', '', 'sendMe', '2019-08-23 03:14:39');

-- ----------------------------
-- Table structure for test
-- ----------------------------
DROP TABLE IF EXISTS `test`;
CREATE TABLE `test` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `msg` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of test
-- ----------------------------
INSERT INTO `test` VALUES ('1', '1111');
INSERT INTO `test` VALUES ('2', '1111');
INSERT INTO `test` VALUES ('3', '1111');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '2222', '123456');
