package com.example.demo.user;

import com.alibaba.fastjson.JSONArray;
import com.example.demo.user.pojo.User;
import com.example.demo.user.repository.UserRepository;
import com.github.unclecatmyself.bootstrap.verify.InChatVerifyService;
import com.github.unclecatmyself.common.utils.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * Created by MySelf on 2019/1/3.
 */
public class VerifyServiceImpl implements InChatVerifyService {

    private UserRepository repository;

    public VerifyServiceImpl(UserRepository repository){
        this.repository = repository;
    }

    public boolean verifyToken(String token) {
//            User user = repository.findByUsername(token);
//            if (user.getId() != null){
//                return true;
//            }
            return true;
    }

    public JSONArray getArrayByGroupId(String groupId) {
        JSONArray jsonArray = JSONArray.parseArray("[\"1111\",\"2222\",\"3333\"]");
        return jsonArray;
    }
}
