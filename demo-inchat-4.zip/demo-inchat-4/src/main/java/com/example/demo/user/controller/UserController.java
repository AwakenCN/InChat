package com.example.demo.user.controller;

import com.example.demo.user.FromServerServiceImpl;
import com.example.demo.user.MyInit;
import com.example.demo.user.UserListenAsynData;
import com.example.demo.user.VerifyServiceImpl;
import com.example.demo.user.pojo.User;
import com.example.demo.user.repository.UserRepository;
import com.github.unclecatmyself.auto.ConfigFactory;
import com.github.unclecatmyself.auto.InitServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by MySelf on 2019/8/23.
 */
@RestController
public class UserController {

    @Autowired
    private UserRepository repository;

    @GetMapping("/init")
    public String init(){
        ConfigFactory.initNetty = new MyInit();
        ConfigFactory.fromServerService = FromServerServiceImpl.TYPE2;
        ConfigFactory.listenAsynData = new UserListenAsynData();
        ConfigFactory.inChatVerifyService = new VerifyServiceImpl(repository);
        InitServer.open();
        return "success";
    }

}
