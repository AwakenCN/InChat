package com.example.demo.user;

import com.github.unclecatmyself.common.bean.InChatMessage;
import com.github.unclecatmyself.common.utils.MessageChangeUtil;
import com.github.unclecatmyself.task.ListenAsynData;

import java.util.Map;

/**
 * 1.5版本将移入框架
 * Created by MySelf on 2019/8/20.
 */
public class UserListenAsynData extends ListenAsynData {

    @Override
    public void asynData(Map<String, Object> maps) {

        InChatMessage inChatMessage = MessageChangeUtil.Change(maps);
        CacheMap.add(inChatMessage);

    }
}
