package com.example.demo.user.repository;

import com.example.demo.user.pojo.Message;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by MySelf on 2019/8/21.
 */
public interface MessageRepository extends JpaRepository<Message,Integer> {
}
