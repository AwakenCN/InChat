package com.example.demo.user.task;

import com.example.demo.user.CacheMap;
import com.example.demo.user.pojo.Message;
import com.example.demo.user.repository.MessageRepository;
import com.github.unclecatmyself.common.bean.InChatMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * 数据定时存储
 * Created by MySelf on 2019/8/22.
 */
@Component
public class SchedulerTask {

    @Autowired
    private MessageRepository repository;

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

    @Scheduled(fixedRate = 30000)
    public void reportCurrentTime() {
        System.out.println("现在时间：" + dateFormat.format(new Date()));
        Map<Integer,InChatMessage> Chatcache = CacheMap.copy();
        InChatMessage inChatMessage = Chatcache.get(1);
        Message message = new Message();
        message.setOne(inChatMessage.getOne());
        message.setGroudId(inChatMessage.getGroudId());
        message.setOnline(inChatMessage.getOnline());
        message.setOnlineGroup(inChatMessage.getOnlineGroup());
        message.setToken(inChatMessage.getToken());
        message.setType(inChatMessage.getType());
        message.setValue(inChatMessage.getValue());
        message.setTime(inChatMessage.getTime());
        repository.save(message);


    }
}
