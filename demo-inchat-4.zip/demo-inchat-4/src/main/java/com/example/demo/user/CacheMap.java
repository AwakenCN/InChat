package com.example.demo.user;

import com.github.unclecatmyself.common.bean.InChatMessage;
import org.springframework.cache.annotation.Cacheable;


import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 1.5版本将移入框架
 * Created by MySelf on 2019/8/22.
 */
public class CacheMap {

    private static Map<Integer,InChatMessage> Chatcache = new ConcurrentHashMap<>();

    private static Integer num = 0;

    public static void add(InChatMessage inChatMessage){
        Chatcache.put(++num,inChatMessage);
    }

    public static Map<Integer,InChatMessage> copy(){
        return Chatcache;
    }
}
