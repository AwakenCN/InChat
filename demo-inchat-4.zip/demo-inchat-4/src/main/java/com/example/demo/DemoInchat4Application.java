package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Created by MySelf on 2019/8/22.
 */
@SpringBootApplication
@EnableScheduling
public class DemoInchat4Application  {

    public static void main(String[] args) {
        SpringApplication.run(DemoInchat4Application.class, args);
    }

}
